# Placeholder

## Installation

Install placeholders on your own server.

`git clone git@github.com:mrdink/placeholders.git`

Once cloned, open `/dist/placeholders/index.html` then search and replace `img.sixteenbit.com` with the URL of your site.

Copy `/dist/placeholders/` to the root of your server.

## Forked from [Dummy Image Generator](https://github.com/kingkool68/dummyimage)

## Credit

Code written by Russell Heimlich - http://www.russellheimlich.com/blog

Some code was written by Ruquay K Calloway http://ruquay.com/sandbox/imagettf/ to detect the text bounding box better (see comments in the PHP code.)
